#include <stdio.h>

#define FA ('F' * 256 + 'A')
#define FW ('F' * 256 + 'W')

void main() {
    int a = FA;
    printf ("%d %d %d\n",'F',a>>8,a%256);
    return;
}